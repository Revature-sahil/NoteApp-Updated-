# mvvm_note_app_kotlin_android_studio
This is a Simple but Complete Android Note App with clean architecture, MVVM, Room Database, Navigation Components, Safe Args, and Search View!

## MVVM Note App


<img src="https://user-images.githubusercontent.com/68303716/104845731-aab6f380-58df-11eb-8d76-f126d86aeb8a.jpg" width="267" height="580">
<img src="https://user-images.githubusercontent.com/68303716/104845730-aab6f380-58df-11eb-8f99-5c4394540a2c.jpg" width="267" height="580">  
<img src="https://user-images.githubusercontent.com/68303716/104845729-a985c680-58df-11eb-937e-109eb0bee809.jpg" width="267" height="580">  
<img src="https://user-images.githubusercontent.com/68303716/104845732-ab4f8a00-58df-11eb-9fc8-875ac7a2e92b.jpg" width="267" height="580">  
<img src="https://user-images.githubusercontent.com/68303716/104845733-ab4f8a00-58df-11eb-9afd-cd2085b9b9f0.jpg" width="267" height="580">  
